# Nhật Huy — Bio Page

Trang bio cá nhân dạng static, chạy trực tiếp trên GitHub Pages.

## Cấu trúc

- `index.html` — giao diện
- `styles.css` — giao diện responsive, light/dark theme và animation
- `script.js` — theme, chia sẻ, copy link, QR code
- `assets/` — ảnh đại diện và icon mạng xã hội

## Đưa lên GitHub Pages

1. Tạo một repository mới trên GitHub.
2. Upload toàn bộ các file/thư mục trong project này.
3. Vào **Settings → Pages**.
4. Chọn **Deploy from a branch**.
5. Chọn branch `main` và thư mục `/ (root)`.
6. Lưu lại và chờ GitHub Pages triển khai.

QR code sẽ tự động mã hóa URL thực tế của trang sau khi bạn mở trang GitHub Pages.

## Lưu ý

QR code và nút Share sử dụng URL hiện tại (`window.location.href`), vì vậy không cần sửa code sau khi deploy.
