const body = document.body;
const themeBtn = document.getElementById("themeBtn");
const shareBtn = document.getElementById("shareBtn");
const copyBtn = document.getElementById("copyBtn");
const qrBtn = document.getElementById("qrBtn");
const qrDialog = document.getElementById("qrDialog");
const closeQr = document.getElementById("closeQr");
const downloadQr = document.getElementById("downloadQr");
const toast = document.getElementById("toast");

document.getElementById("year").textContent = new Date().getFullYear();

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2200);
}

function updateThemeIcon() {
  themeBtn.innerHTML = body.classList.contains("dark")
    ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.2 15.1A8.5 8.5 0 0 1 8.9 3.8 8.6 8.6 0 1 0 20.2 15.1Z"/></svg>'
    : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3V1m0 22v-2M4.22 4.22 2.81 2.81m18.38 18.38-1.41-1.41M3 12H1m22 0h-2M4.22 19.78l-1.41 1.41M21.19 2.81l-1.41 1.41M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12Z"/></svg>';
}

const savedTheme = localStorage.getItem("nh-theme");
if (savedTheme === "dark" || (!savedTheme && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
  body.classList.add("dark");
}
updateThemeIcon();

themeBtn.addEventListener("click", () => {
  body.classList.toggle("dark");
  localStorage.setItem("nh-theme", body.classList.contains("dark") ? "dark" : "light");
  updateThemeIcon();
});

async function sharePage() {
  const data = {
    title: "Nhật Huy — Bio",
    text: "Kết nối với Nhật Huy",
    url: window.location.href
  };
  if (navigator.share) {
    try {
      await navigator.share(data);
      return;
    } catch (e) {}
  }
  try {
    await navigator.clipboard.writeText(window.location.href);
    showToast("Đã sao chép link trang!");
  } catch {
    showToast("Hãy sao chép link trên thanh địa chỉ.");
  }
}
shareBtn.addEventListener("click", sharePage);

copyBtn.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(window.location.href);
    showToast("Đã sao chép link!");
  } catch {
    showToast("Không thể tự động sao chép link.");
  }
});

function createQr() {
  const box = document.getElementById("qrcode");
  box.innerHTML = "";
  if (typeof QRCode === "undefined") {
    box.innerHTML = "<p style='font-size:12px'>Không tải được thư viện QR.</p>";
    return;
  }
  new QRCode(box, {
    text: window.location.href,
    width: 200,
    height: 200,
    correctLevel: QRCode.CorrectLevel.H
  });
}

qrBtn.addEventListener("click", () => {
  createQr();
  qrDialog.showModal();
});

closeQr.addEventListener("click", () => qrDialog.close());

qrDialog.addEventListener("click", (event) => {
  if (event.target === qrDialog) qrDialog.close();
});

downloadQr.addEventListener("click", () => {
  const canvas = document.querySelector("#qrcode canvas");
  const img = document.querySelector("#qrcode img");
  const source = canvas ? canvas.toDataURL("image/png") : (img ? img.src : null);
  if (!source) {
    showToast("QR chưa sẵn sàng.");
    return;
  }
  const a = document.createElement("a");
  a.href = source;
  a.download = "nhat-huy-bio-qr.png";
  a.click();
});
